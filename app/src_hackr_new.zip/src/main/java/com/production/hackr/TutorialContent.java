package com.production.hackr;

/**
 * Created by Vidushi Sharma on 7/21/2017.
 */

public class TutorialContent {
    public String tut_name;
    public String submitted_by;
    public String upvotes;
    public String source;
    public String status;
}
